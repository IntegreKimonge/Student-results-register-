#ifndef ALGORITHMS_H
#define ALGORITHMS_H
#include <cstddef>
#include <random>
#include <utility>

// comp(a, b) means: a belongs before b.
// Invariant: before iteration i, the first i elements are already sorted.
template <typename T, typename Compare>
void insertionSort(T* array, std::size_t size, Compare comp) {
    for (std::size_t i = 1; i < size; ++i) {
        T key = array[i];
        std::size_t j = i;
        while (j > 0 && comp(key, array[j - 1])) {
            array[j] = array[j - 1];
            --j;
        }
        array[j] = key;
    }
}

namespace detail {
template <typename T, typename Compare>
void quickRange(T* array, std::size_t first, std::size_t end, Compare comp, std::mt19937& random) {
    while (end - first > 1) {
        std::uniform_int_distribution<std::size_t> choose(first, end - 1);
        T pivot = array[choose(random)];
        std::size_t less = first, current = first, greater = end;
        // Three groups: before the pivot, equal to it, and after it.
        while (current < greater) {
            if (comp(array[current], pivot)) {
                std::swap(array[less], array[current]);
                ++less;
                ++current;
            } else if (comp(pivot, array[current])) {
                --greater;
                std::swap(array[current], array[greater]);
            } else ++current;
        }
        // Recurse on the smaller group to limit stack memory.
        if (less - first < end - greater) {
            quickRange(array, first, less, comp, random);
            first = greater;
        } else {
            quickRange(array, greater, end, comp, random);
            end = less;
        }
    }
}

}

template <typename T, typename Compare>
void quickSort(T* array, std::size_t size, Compare comp, unsigned seed = 2437) {
    std::mt19937 random(seed); // Repeatable pseudorandom pivots for testing.
    detail::quickRange(array, 0, size, comp, random);
}

// Iterative search for the FIRST match; input must use the same sort order.
template <typename T, typename Key, typename Compare>
long binarySearch(const T* array, std::size_t size, const Key& key, Compare compare) {
    std::size_t first = 0, end = size;
    while (first < end) {
        std::size_t middle = first + (end - first) / 2;
        if (compare(array[middle], key) < 0) first = middle + 1;
        else end = middle;
    }
    if (first < size && compare(array[first], key) == 0) return static_cast<long>(first);
    return -1;
}
#endif
