#include <iomanip>
#include <iostream>
#include <sstream>
#include "StudentResult.h"
#include "DynamicArray.h"
#include "Algorithms.h"
using Register = DynamicArray<StudentResult>;
using namespace std;

bool readNumber(const string& prompt, int& value) {
    string line;
    while (cout << prompt, getline(cin, line)) {
        istringstream input(line);
        if (input >> value) {
            input >> ws;
            if (input.eof()) return true;
        }
        cout << "Enter a whole number.\n";
    }
    return false;
}

bool readText(const string& prompt, string& text) {
    cout << prompt;
    return static_cast<bool>(getline(cin, text));
}

long findStudent(const Register& records, const string& regNo) {
    for (size_t i = 0; i < records.size(); ++i)
        if (records[i].regNo == regNo) return static_cast<long>(i);
    return -1;
}

void show(const Register& records) {
    cout << "\nRecords: " << records.size() << "  Capacity: " << records.capacity() << '\n';
    cout << left << setw(16) << "Registration" << setw(22) << "Name"
         << setw(12) << "Course" << "Score Grade\n";
    for (size_t i = 0; i < records.size(); ++i)
        cout << left << setw(16) << records[i].regNo << setw(22) << records[i].name
             << setw(12) << records[i].course << setw(6) << records[i].score
             << records[i].grade() << '\n';
}

bool save(const Register& records, const string& file) {
    if (!records.saveToFile(file)) {
        cerr << "Could not save to " << file << ".\n";
        return false;
    }
    cout << "Saved " << records.size() << " records to " << file << ".\n";
    return true;
}

int run(int argc, char** argv) {
    string file = argc > 1 ? argv[1] : "students.txt";
    Register records;
    size_t skipped = 0;
    if (!records.loadFromFile(file, &skipped)) {
        cerr << "Cannot read " << file << ".\n";
        return 1;
    }
    if (skipped != 0) {
        cerr << skipped << " invalid lines. Correct the file before editing it.\n";
        return 1;
    }
    // This small application stores one result per registration number.
    for (size_t i = 0; i < records.size(); ++i) {
        if (findStudent(records, records[i].regNo) != static_cast<long>(i)) {
            cerr << "Duplicate registration number: " << records[i].regNo << '\n';
            return 1;
        }
    }

    cout << "Registration number VU-BCS-2403-1433-DAY ends in 3 (odd): using quicksort with a random pivot.\n";
    bool changed = false;
    int choice;
    while (true) {
        cout << "\n1 Display  2 Add  3 Update score  4 Remove\n"
             << "5 Rank by score  6 Search  7 Save  0 Save and exit\n";
        if (!readNumber("Choice: ", choice) || choice == 0) break;
        if (choice == 1) show(records);
        else if (choice == 2) {
            StudentResult student;
            if (!readText("Registration number: ", student.regNo) ||
                !readText("Name: ", student.name) || !readText("Course: ", student.course) ||
                !readNumber("Score (0-100): ", student.score)) break;
            if (!student.valid()) cout << "Invalid record: fill every field and use a score from 0 to 100.\n";
            else if (findStudent(records, student.regNo) >= 0) cout << "Registration number already exists.\n";
            else { records.pushBack(student); changed = true; cout << "Student added.\n"; }
        } else if (choice == 3 || choice == 4) {
            string key;
            if (!readText("Registration number: ", key)) break;
            long index = findStudent(records, key);
            if (index < 0) { cout << "Student not found.\n"; continue; }
            if (choice == 4) { records.removeAt(index); changed = true; cout << "Student removed.\n"; }
            else {
                StudentResult updated = records[index];
                if (!readNumber("New score (0-100): ", updated.score)) break;
                if (!updated.valid()) cout << "Score must be from 0 to 100.\n";
                else { records.set(index, updated); changed = true; cout << "Score updated.\n"; }
            }
        } else if (choice == 5) {
            quickSort(records.data(), records.size(), byScore);
            changed = true;
            show(records);
        } else if (choice == 6) {
            string key;
            if (!readText("Registration number: ", key)) break;
            Register sorted(records); // Deep copy keeps the displayed order unchanged.
            insertionSort(sorted.data(), sorted.size(), byRegistration);
            long index = binarySearch(sorted.data(), sorted.size(), key, compareRegistration);
            if (index < 0) cout << "Student not found.\n";
            else cout << sorted[index] << "  Grade " << sorted[index].grade() << '\n';
        } else if (choice == 7) {
            if (save(records, file)) changed = false;
        } else cout << "Choose one of the listed options.\n";
    }
    return changed && !save(records, file) ? 1 : 0;
}

int main(int argc, char** argv) {
    try { return run(argc, argv); }
    catch (const exception& error) { cerr << "Error: " << error.what() << '\n'; return 1; }
}
