#ifndef STUDENT_RESULT_H
#define STUDENT_RESULT_H
#include <iostream>
#include <sstream>
#include <string>

struct StudentResult {
    std::string regNo, name, course;
    int score = 0;

    static bool validText(const std::string& text) {
        return text.find_first_not_of(" \t\r\n") != std::string::npos &&
               text.find_first_of("|\r\n") == std::string::npos;
    }
    bool valid() const {
        return validText(regNo) && validText(name) && validText(course) &&
               score >= 0 && score <= 100;
    }
    char grade() const {
        if (score >= 80) return 'A';
        if (score >= 70) return 'B';
        if (score >= 60) return 'C';
        if (score >= 50) return 'D';
        return 'F';
    }
};

// The same validation is used for file input and menu input.
inline std::istream& operator>>(std::istream& input, StudentResult& result) {
    std::string line, scoreText;
    if (!std::getline(input, line)) return input;
    if (!line.empty() && line.back() == '\r') line.pop_back();
    std::istringstream fields(line);
    StudentResult parsed;
    bool fieldsOK = static_cast<bool>(std::getline(fields, parsed.regNo, '|')) &&
                    static_cast<bool>(std::getline(fields, parsed.name, '|')) &&
                    static_cast<bool>(std::getline(fields, parsed.course, '|')) &&
                    static_cast<bool>(std::getline(fields, scoreText));
    std::istringstream number(scoreText);
    if (fieldsOK && (number >> parsed.score)) {
        number >> std::ws;
        if (number.eof() && parsed.valid()) { result = parsed; return input; }
    }
    input.setstate(std::ios::failbit);
    return input;
}

inline std::ostream& operator<<(std::ostream& output, const StudentResult& result) {
    return output << result.regNo << '|' << result.name << '|'
                  << result.course << '|' << result.score;
}

inline bool byScore(const StudentResult& a, const StudentResult& b) { return a.score > b.score; }
inline bool byRegistration(const StudentResult& a, const StudentResult& b) { return a.regNo < b.regNo; }
inline int compareRegistration(const StudentResult& a, const std::string& key) { return a.regNo.compare(key); }
#endif
