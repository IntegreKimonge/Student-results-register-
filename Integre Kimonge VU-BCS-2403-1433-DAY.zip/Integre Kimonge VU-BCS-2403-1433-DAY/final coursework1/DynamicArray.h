#ifndef DYNAMIC_ARRAY_H
#define DYNAMIC_ARRAY_H
#include <cstddef>
#include <fstream>
#include <limits>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>

// Our own dynamic array. The temporary smart pointer only prevents memory leaks.
template <typename T>
class DynamicArray {
    std::size_t size_ = 0, capacity_;
    T* data_;

    static T* copyBuffer(const T* source, std::size_t count, std::size_t capacity) {
        std::unique_ptr<T[]> buffer(new T[capacity]);
        for (std::size_t i = 0; i < count; ++i) buffer[i] = source[i];
        return buffer.release();
    }

    void grow() {
        if (capacity_ > std::numeric_limits<std::size_t>::max() / 2)
            throw std::length_error("Array is too large");
        std::size_t next = capacity_ * 2;
        T* bigger = copyBuffer(data_, size_, next);
        delete[] data_;
        data_ = bigger;
        capacity_ = next;
    }

public:
    explicit DynamicArray(std::size_t capacity = 4)
        : capacity_(capacity == 0 ? 1 : capacity), data_(new T[capacity_]) {}

    ~DynamicArray() { delete[] data_; }

    DynamicArray(const DynamicArray& other)
        : size_(other.size_), capacity_(other.capacity_),
          data_(copyBuffer(other.data_, other.size_, other.capacity_)) {}

    DynamicArray& operator=(DynamicArray other) {
        swap(other);
        return *this;
    }

    void swap(DynamicArray& other) noexcept {
        std::swap(size_, other.size_);
        std::swap(capacity_, other.capacity_);
        std::swap(data_, other.data_);
    }

    std::size_t size() const { return size_; }
    std::size_t capacity() const { return capacity_; }
    bool empty() const { return size_ == 0; }
    T* data() { return data_; }
    const T* data() const { return data_; }
    void clear() { size_ = 0; }

    // Copy the value BEFORE resizing or shifting: it may come from this array.
    void pushBack(T value) {
        if (size_ == capacity_) grow();
        data_[size_] = value;
        ++size_;
    }

    bool insertAt(std::size_t index, T value) {
        if (index > size_) return false;
        if (size_ == capacity_) grow();
        for (std::size_t i = size_; i > index; --i) data_[i] = data_[i - 1];
        data_[index] = value;
        ++size_;
        return true;
    }

    bool removeAt(std::size_t index, T* removed = nullptr) {
        if (index >= size_) return false;
        if (removed) *removed = data_[index];
        for (std::size_t i = index; i + 1 < size_; ++i) data_[i] = data_[i + 1];
        --size_;
        return true;
    }

    bool popBack(T* removed = nullptr) {
        return !empty() && removeAt(size_ - 1, removed);
    }

    T* get(std::size_t index) { return index < size_ ? &data_[index] : nullptr; }
    const T* get(std::size_t index) const { return index < size_ ? &data_[index] : nullptr; }
    bool set(std::size_t index, const T& value) {
        if (index >= size_) return false;
        data_[index] = value;
        return true;
    }

    // [] requires a valid index. Use get() or at() when the index is uncertain.
    T& operator[](std::size_t index) { return data_[index]; }
    const T& operator[](std::size_t index) const { return data_[index]; }
    T& at(std::size_t index) {
        if (index >= size_) throw std::out_of_range("Invalid array index");
        return data_[index];
    }
    const T& at(std::size_t index) const {
        if (index >= size_) throw std::out_of_range("Invalid array index");
        return data_[index];
    }

    bool loadFromFile(const std::string& path, std::size_t* skipped = nullptr) {
        std::ifstream input(path);
        if (!input) return false;
        DynamicArray loaded;
        std::string line;
        std::size_t bad = 0;
        while (std::getline(input, line)) {
            std::istringstream row(line);
            T value{};
            if (row >> value) {
                row >> std::ws;
                if (row.eof()) { loaded.pushBack(value); continue; }
            }
            ++bad;
        }
        if (input.bad()) return false;
        swap(loaded); // Replace the old contents only after reading succeeds.
        if (skipped) *skipped = bad;
        return true;
    }

    bool saveToFile(const std::string& path) const {
        std::ofstream output(path);
        if (!output) return false;
        for (std::size_t i = 0; i < size_; ++i) output << data_[i] << '\n';
        output.close(); // Check errors that occur when buffered output is written.
        return static_cast<bool>(output);
    }
};
#endif
