// Usage: ./bench > bench.csv
#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <random>
#include "StudentResult.h"
#include "DynamicArray.h"
#include "Algorithms.h"
using namespace std;
using Clock = chrono::steady_clock;

int main() {
    mt19937 random(12345);
    uniform_int_distribution<int> score(0, 100);
    cout << "n,insertion_ms,quick_ms,insertion_ratio,quick_ratio\n";
    cout << fixed << setprecision(6);
    double previousInsertion = 0, previousOther = 0;
    for (size_t size = 1000; size <= 64000; size *= 2) {
        double insertionTime = 0, otherTime = 0;
        for (int repeat = 0; repeat < 3; ++repeat) {
            DynamicArray<StudentResult> input;
            for (size_t i = 0; i < size; ++i)
                input.pushBack({"REG/" + to_string(i), "Student " + to_string(i), "CSC2101", score(random)});
            DynamicArray<StudentResult> a(input), b(input);
            auto start = Clock::now();
            insertionSort(a.data(), a.size(), byScore);
            auto middle = Clock::now();
            quickSort(b.data(), b.size(), byScore, 2437 + repeat);
            auto end = Clock::now();
            insertionTime += chrono::duration<double, milli>(middle - start).count();
            otherTime += chrono::duration<double, milli>(end - middle).count();
            // Verify outside the timed section and keep the result observable.
            if (!is_sorted(a.data(), a.data() + a.size(), byScore) ||
                !is_sorted(b.data(), b.data() + b.size(), byScore)) {
                cerr << "Sort failed at n=" << size << '\n';
                return 1;
            }
        }
        insertionTime /= 3;
        otherTime /= 3;
        cout << size << ',' << insertionTime << ',' << otherTime << ',';
        if (previousInsertion > 0 && previousOther > 0)
            cout << insertionTime / previousInsertion << ',' << otherTime / previousOther;
        else cout << "NA,NA";
        cout << endl;
        previousInsertion = insertionTime;
        previousOther = otherTime;
    }
}
