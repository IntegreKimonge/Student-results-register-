// Test harness: prints the A3 test table (ID | operation | expected | actual | result)
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <chrono>
#include <filesystem>
#include <cstdlib>
#include "StudentResult.h"
#include "DynamicArray.h"
#include "Algorithms.h"
using namespace std;
typedef DynamicArray<StudentResult> Reg;
static int fails = 0, total = 0;

static void row(const string& id, const string& op, const string& exp, const string& act) {
    bool ok = exp == act; ++total; if (!ok) ++fails;
    cout << id << " | " << op << " | " << exp << " | " << act << " | " << (ok ? "PASS" : "FAIL") << "\n";
}
static StudentResult mk(const string& r, int s) { return StudentResult{r, "N_" + r, "CSC2101", s}; }
static string order(const Reg& r) { ostringstream o; for (size_t i = 0; i < r.size(); ++i) o << (i ? "," : "") << r[i].regNo; return o.str(); }
static string scores(const Reg& r) { ostringstream o; for (size_t i = 0; i < r.size(); ++i) o << (i ? "," : "") << r[i].score; return o.str(); }
static string num(long x) { return to_string(x); }
static bool byScoreAsc(const StudentResult& a, const StudentResult& b) { return a.score < b.score; }
static bool byScoreDesc(const StudentResult& a, const StudentResult& b) { return a.score > b.score; }
static bool byReg(const StudentResult& a, const StudentResult& b) { return a.regNo < b.regNo; }
static int cmpReg(const StudentResult& r, const string& k) { return r.regNo.compare(k); }

// Temporary test files never overwrite the application's saved register.
struct TestFiles {
    filesystem::path folder = filesystem::temp_directory_path() /
        ("register-tests-" + to_string(chrono::steady_clock::now().time_since_epoch().count()));
    TestFiles() { filesystem::create_directory(folder); }
    ~TestFiles() { error_code error; filesystem::remove_all(folder, error); }
    string path(const string& name) const { return (folder / name).string(); }
};

// Counts live objects so failed allocation/copy paths can be checked for leaks.
struct ThrowingValue {
    inline static int alive = 0;
    inline static bool failCopy = false;
    int value = 0;
    ThrowingValue(int value = 0) : value(value) { ++alive; }
    ThrowingValue(const ThrowingValue& other) : value(other.value) { ++alive; }
    ~ThrowingValue() { --alive; }
    ThrowingValue& operator=(const ThrowingValue& other) {
        if (failCopy) throw runtime_error("Deliberate test failure");
        value = other.value;
        return *this;
    }
};

int main(int argc, char** argv) {
    TestFiles files;
    string sample = argc > 1 ? argv[1] : "students.txt";
    cout << "ID | Operation | Expected | Actual | Result\n";
    // ---------- A1: structure ----------
    { Reg r; row("T01", "New register: size / empty()", "0/1", num(r.size()) + "/" + num(r.empty())); }
    { Reg r; row("T02", "removeAt(0) on empty", "rejected", r.removeAt(0) ? "accepted" : "rejected");
             row("T03", "popBack() on empty", "rejected", r.popBack() ? "accepted" : "rejected");
             row("T04", "get(0) on empty", "nullptr", r.get(0) ? "valid" : "nullptr"); }
    { Reg r(2); r.pushBack(mk("A", 1)); row("T05", "Add ONE record", "size=1 cap=2", "size=" + num(r.size()) + " cap=" + num(r.capacity()));
      r.pushBack(mk("B", 2)); r.pushBack(mk("C", 3));
      row("T06", "3rd pushBack when cap=2 (doubling)", "size=3 cap=4", "size=" + num(r.size()) + " cap=" + num(r.capacity()));
      r.pushBack(mk("D", 4)); r.pushBack(mk("E", 5));
      row("T07", "5th pushBack when cap=4 (doubling)", "size=5 cap=8", "size=" + num(r.size()) + " cap=" + num(r.capacity())); }
    { Reg r; for (const char* k : {"A", "B", "C", "D"}) r.pushBack(mk(k, 0));
      StudentResult g; r.removeAt(0, &g);
      row("T08", "Remove FIRST of A,B,C,D", "A / B,C,D", g.regNo + " / " + order(r));
      r.removeAt(r.size() - 1, &g);
      row("T09", "Remove LAST of B,C,D", "D / B,C", g.regNo + " / " + order(r));
      row("T10", "removeAt(index = size) (out of range)", "rejected", r.removeAt(r.size()) ? "accepted" : "rejected");
      row("T11", "insertAt(index > size)", "rejected", r.insertAt(5, mk("Z", 0)) ? "accepted" : "rejected");
      r.insertAt(0, mk("X", 0)); r.insertAt(r.size(), mk("Y", 0)); r.insertAt(1, mk("M", 0));
      row("T12", "insertAt front, back, middle", "X,M,B,C,Y", order(r));
      row("T13", "set(99) invalid index", "rejected", r.set(99, mk("Q", 0)) ? "accepted" : "rejected");
      row("T14", "at(99) throws out_of_range", "exception", [&] { try { r.at(99); } catch (const out_of_range&) { return "exception"; } return "no exception"; }()); }
    { Reg a; a.pushBack(mk("A", 1)); a.pushBack(mk("B", 2)); Reg b(a); b.set(0, mk("Z", 9));
      row("T15", "Copy constructor is DEEP (edit copy)", "A,B (orig unchanged)", order(a) + " (orig " + (a[0].regNo == "A" ? "unchanged)" : "CHANGED)"));
      Reg c; c = a; c.pushBack(mk("C", 3)); Reg& same = a; a = same;
      row("T16", "Assignment copy + self-assignment", "orig=2 copy=3", "orig=" + num(a.size()) + " copy=" + num(c.size())); }
    // ---------- A1: file I/O ----------
    { Reg r; size_t sk = 0; bool ok = r.loadFromFile(sample, &sk);
      row("T17", "Load fixed sample (12 records)", "true,12,0 skipped", string(ok ? "true" : "false") + "," + num(r.size()) + "," + num(sk) + " skipped");
      r.pushBack(mk("2023/BIT/099", 66)); bool saved = r.saveToFile(files.path("out.txt"));
      Reg s; bool loaded = s.loadFromFile(files.path("out.txt"));
      ostringstream before, after;
      for (size_t i = 0; i < r.size(); ++i) before << r[i] << '\n';
      for (size_t i = 0; i < s.size(); ++i) after << s[i] << '\n';
      row("T18", "Save/reload: every field preserved", "true", saved && loaded && before.str() == after.str() ? "true" : "false"); }
    { Reg r; row("T19", "Load non-existent file", "false", r.loadFromFile(files.path("missing.txt")) ? "true" : "false"); }
    { ofstream o(files.path("bad.txt")); o << "2023/X/1|Ann|CSC|55\r\n\ngarbage line\n2023/X/2|Bob|CSC|150\n2023/X/3|Cy|CSC|abc\n2023/X/4|Di|CSC|70\n"; o.close();
      Reg r; size_t sk = 0; r.loadFromFile(files.path("bad.txt"), &sk);
      row("T20", "Malformed file: blank, garbage, score 150, score 'abc', CRLF", "2 loaded, 4 skipped", num(r.size()) + " loaded, " + num(sk) + " skipped"); }
    // ---------- A2: sorting ----------
    for (int alg = 0; alg < 2; ++alg) {
        string n = alg == 0 ? "Insertion sort" : "Random-pivot quicksort";
        string p = alg == 0 ? "I" : "Q";
        auto S = [&](Reg& r, bool (*c)(const StudentResult&, const StudentResult&)) {
            if (alg == 0) insertionSort(r.data(), r.size(), c);
            else quickSort(r.data(), r.size(), c); };
        { Reg r; S(r, byScoreAsc); row(p + "1", n + ": empty register", "no crash, size 0", "no crash, size " + num(r.size())); }
        { Reg r; r.pushBack(mk("A", 5)); S(r, byScoreAsc); row(p + "2", n + ": one record", "5", scores(r)); }
        { Reg r; for (int s : {1, 2, 3, 4, 5}) r.pushBack(mk("R", s)); S(r, byScoreAsc); row(p + "3", n + ": already sorted", "1,2,3,4,5", scores(r)); }
        { Reg r; for (int s : {5, 4, 3, 2, 1}) r.pushBack(mk("R", s)); S(r, byScoreAsc); row(p + "4", n + ": reversed input", "1,2,3,4,5", scores(r)); }
        { Reg r; for (int s : {3, 1, 2, 1, 3, 2}) r.pushBack(mk("R", s)); S(r, byScoreAsc); row(p + "5", n + ": duplicate scores", "1,1,2,2,3,3", scores(r)); }
        { Reg r; r.pushBack(mk("first", 70)); r.pushBack(mk("second", 90)); r.pushBack(mk("third", 70)); r.pushBack(mk("fourth", 90));
          S(r, byScoreDesc);
          if (alg == 0) row("I6", "Insertion sort: stability on equal scores", "second,fourth,first,third", order(r));
          else row("Q6", "Quicksort descending; ties may change order", "90,90,70,70", scores(r)); }
        { Reg r; for (const char* key : {"C", "A", "B"}) r.pushBack(mk(key, 50));
          S(r, byReg); row(p + "7", n + ": different comparator (regNo)", "A,B,C", order(r)); }
    }
    // random cross-check against std::stable_sort
    { srand(7); bool ok = true;
      for (int t = 0; t < 200 && ok; ++t) {
          int n = rand() % 60; Reg a, b, c; for (int i = 0; i < n; ++i) { StudentResult s = mk("R" + to_string(i), rand() % 10); a.pushBack(s); b.pushBack(s); c.pushBack(s); }
          insertionSort(a.data(), a.size(), byScoreAsc); quickSort(b.data(), b.size(), byScoreAsc, 2427 + t);
          stable_sort(c.data(), c.data() + c.size(), byScoreAsc);
          ok = order(a) == order(c) && scores(b) == scores(c);
          // Quicksort may reorder ties, but must preserve every complete record.
          insertionSort(b.data(), b.size(), byReg); insertionSort(c.data(), c.size(), byReg);
          for (size_t i = 0; i < b.size(); ++i) {
              ostringstream actual, expected; actual << b[i]; expected << c[i];
              ok = ok && actual.str() == expected.str();
          } }
      row("C01", "200 arrays/seeds: insertion stable, quicksort sorted, all records preserved", "all match", ok ? "all match" : "MISMATCH"); }
    // ---------- A2: binary search ----------
    { Reg r; for (const char* k : {"E", "A", "C", "B", "D"}) r.pushBack(mk(k, 0));
      quickSort(r.data(), r.size(), byReg);
      row("B1", "Binary search: present key 'A' (first)", "0", num(binarySearch(r.data(), r.size(), string("A"), cmpReg)));
      row("B2", "Binary search: present key 'E' (last)", "4", num(binarySearch(r.data(), r.size(), string("E"), cmpReg)));
      row("B3", "Binary search: present key 'C' (middle)", "2", num(binarySearch(r.data(), r.size(), string("C"), cmpReg)));
      row("B4", "Binary search: ABSENT key 'Z'", "-1", num(binarySearch(r.data(), r.size(), string("Z"), cmpReg)));
      row("B5", "Binary search: absent key below range '0'", "-1", num(binarySearch(r.data(), r.size(), string("0"), cmpReg))); }
    { Reg r; row("B6", "Binary search: empty register", "-1", num(binarySearch(r.data(), r.size(), string("A"), cmpReg))); }
    { Reg r; r.pushBack(mk("A", 0)); row("B7", "Binary search: one record (hit / miss)", "0 / -1", num(binarySearch(r.data(), r.size(), string("A"), cmpReg)) + " / " + num(binarySearch(r.data(), r.size(), string("B"), cmpReg))); }
    { Reg r; for (const char* k : {"B", "A", "B", "B", "C"}) r.pushBack(mk(k, 0)); quickSort(r.data(), r.size(), byReg);
      row("B8", "Binary search: DUPLICATE key 'B' (returns first)", "1", num(binarySearch(r.data(), r.size(), string("B"), cmpReg))); }

    // Regression tests for the problems found during the review.
    { Reg r(1); r.pushBack(mk("A", 20)); r.pushBack(r[0]);
      row("R01", "Append own element while growing", "A,A", order(r)); }
    { Reg r(4); for (const char* key : {"A", "B", "C"}) r.pushBack(mk(key, 20));
      r.insertAt(0, r[1]); row("R02", "Insert own element while shifting", "B,A,B,C", order(r)); }
    { Reg r(1); r.pushBack(mk("A", 20)); r.insertAt(0, r[0]);
      row("R03", "Insert own element while growing", "A,A", order(r)); }
    { Reg a(0); a.pushBack(mk("A", 20)); Reg b(std::move(a)); a.pushBack(mk("B", 30));
      row("R04", "Rvalue safely uses deep copy; source remains usable", "A,B / A", order(a) + " / " + order(b)); }
    { Reg a; a.pushBack(mk("A", 20)); Reg b; b = a; b.set(0, mk("B", 30));
      row("R05", "Assignment creates independent elements", "A / B", order(a) + " / " + order(b)); }
    { Reg r; r.pushBack(mk("A", 20)); bool ok = r.loadFromFile(files.path("missing.txt"));
      row("R06", "Failed load preserves existing records", "false / A", string(ok ? "true" : "false") + " / " + order(r));
      row("R07", "Save to a missing directory reports failure", "false", r.saveToFile(files.path("missing/out.txt")) ? "true" : "false"); }
    { int id = 8;
      for (const char* line : {"|Ann|CSC|55", "A||CSC|55", "A|Ann||55", "A|   |CSC|55",
                              "A|Ann|CSC|-1", "A|Ann|CSC|101", "A|Ann|CSC|55abc", "A|Ann|CSC|55|extra"}) {
          istringstream input(line); StudentResult r = mk("unchanged", 10); bool accepted = bool(input >> r);
          row("R" + num(id++), string("Reject invalid record: ") + line, "rejected, unchanged",
              string(accepted ? "accepted" : "rejected") + ", " + r.regNo);
      } }
    { StudentResult r = mk("A", 0);
      bool ok = r.valid(); r.score = 100; ok = ok && r.valid();
      r.score = 150; ok = ok && !r.valid(); r.score = 50; r.name = "Ann|Bob"; ok = ok && !r.valid();
      row("R16", "Application validation: score limits and separator", "true", ok ? "true" : "false"); }
    { ofstream out(files.path("numbers.txt")); out << "1\nwrong\n2\n3 extra\n"; out.close();
      DynamicArray<int> numbers; size_t skipped = 0; numbers.loadFromFile(files.path("numbers.txt"), &skipped);
      row("R17", "Generic loader makes progress after malformed line", "2 / 2", num(numbers.size()) + " / " + num(skipped)); }
    { Reg a; for (const char* key : {"C", "A", "B", "D"}) a.pushBack(mk(key, 50));
      Reg b(a); insertionSort(a.data(), a.size(), byScoreAsc); quickSort(b.data(), b.size(), byScoreAsc);
      row("R18", "All equal keys: insertion stable, quicksort keeps all scores", "C,A,B,D / 50,50,50,50", order(a) + " / " + scores(b)); }
    { DynamicArray<ThrowingValue> original(1); original.pushBack(ThrowingValue(7));
      ThrowingValue::failCopy = true; bool caught = false;
      try { DynamicArray<ThrowingValue> copy(original); } catch (const runtime_error&) { caught = true; }
      row("R19", "Failed copy releases temporary buffer", "true / 1", string(caught ? "true" : "false") + " / " + num(ThrowingValue::alive));
      caught = false;
      try { original.pushBack(ThrowingValue(9)); } catch (const runtime_error&) { caught = true; }
      ThrowingValue::failCopy = false;
      row("R20", "Failed growth preserves original and releases buffer", "true / 1 / 7 / 1",
          string(caught ? "true" : "false") + " / " + num(original.size()) + " / " + num(original[0].value) + " / " + num(ThrowingValue::alive)); }
    row("R21", "Destructor releases every tracked object", "0", num(ThrowingValue::alive));
    cout << "\nSUMMARY: " << (total - fails) << "/" << total << " passed\n";
    return fails ? 1 : 0;
}
